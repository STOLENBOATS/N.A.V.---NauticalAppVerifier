// config.example.js — copia para config.js e preenche
window.MIEC_CONFIG = {
  SUPA_URL: 'https://<teu-project-ref>.supabase.co',
  SUPA_KEY: '<anon-key>',
  APP_VERSION: 'v4.2.1-auth-min — 2025-08-26',
  SYNC_EXTRA_WIN_FIELDS: true,
  SYNC_EXTRA_MOTOR_FIELDS: true
};